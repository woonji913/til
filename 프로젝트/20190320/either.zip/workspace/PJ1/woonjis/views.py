from django.shortcuts import render, redirect
from .models import Question, Answer
# Create your views here.

def index(request):
    questions = Question.objects.all()
    context = {
        'questions': questions,
    }
    return render(request, 'woonjis/index.html', context)

def new(request):
    #NEW
    if request.method == 'GET':
        return render(request, 'woonjis/new.html')
    #CREATE
    else:
        title = request.POST.get('title')
        select1 = request.POST.get('select1')
        image1 = request.FILES.get('image1')
        select2 = request.POST.get('select2')
        image2 = request.FILES.get('image2')
        question = Question(title=title, select1=select1, select2=select2, image1=image1, image2=image2)
        question.save()
        return redirect('woonjis:detail', question.pk)

def detail(request, question_pk):
    question = Question.objects.get(pk=question_pk)
    answers = question.answer_set.all()
    a = len(answers)
    if a:
        c = 0
        for answer in answers:
            if answer.pick: c += 1
    else:
        a = 100
        c = 0
    b = a - c
    n1 = round((c / a)*100,2)
    n2 = round((b / a)*100,2)

    context = {
        'question': question,
        'answers': answers,
        'c':c,
        'n1':n1,
        'n2':n2,
        'a':a,
        'b':b,
    }
    return render(request, 'woonjis/detail.html', context)
    
def answers_create(request, question_pk):
    question = Question.objects.get(pk=question_pk)
    comment = request.POST.get('comment')
    pick = int(request.POST.get('select'))
    answer = Answer(question=question, pick=pick, comment=comment)
    answer.save()
    return redirect('woonjis:detail', question_pk)
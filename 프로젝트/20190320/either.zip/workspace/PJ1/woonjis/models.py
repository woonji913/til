from django.db import models
from imagekit.models import ProcessedImageField
from imagekit.processors import ResizeToFill

def woonji_image_path(instance, filename):
    return f'woonji/{instance.pk}/images/{filename}'
    
# Create your models here.
class Question(models.Model):
    title = models.CharField(max_length=50)
    image1 = ProcessedImageField(# 이 안의 속성값이 바뀌는건 migrate 안해줘도 되요.
        blank = True,
        upload_to=woonji_image_path,              # 저장 위치
        processors=[ResizeToFill(300,300)],    # 처리할 작업 목록 : ResizeToFill : 지정한 사이즈를 맞추고 넘치는 부분을 잘라냄
                                                #                    ResizeToFit : 지정한 사이즈를 맞추고 너 
        format='JPEG',                          # 저장 포맷
        options={'quality':90},                 # 옵션
        )
    image2 = ProcessedImageField(# 이 안의 속성값이 바뀌는건 migrate 안해줘도 되요.
        blank = True,
        upload_to=woonji_image_path,              # 저장 위치
        processors=[ResizeToFill(300,300)],     # 처리할 작업 목록 : ResizeToFill : 지정한 사이즈를 맞추고 넘치는 부분을 잘라냄
                                                #                    ResizeToFit : 지정한 사이즈를 맞추고 너 
        format='JPEG',                          # 저장 포맷
        options={'quality':90},                 # 옵션
        )
    select1 = models.TextField()
    select2 = models.TextField()

    def __str__(self):
        return f"{self.title}, {self.select1} vs {self.select2}"
        
class Answer(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    pick = models.BooleanField()
    comment = models.CharField(max_length=200)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.pick}/{self.comment}"
    
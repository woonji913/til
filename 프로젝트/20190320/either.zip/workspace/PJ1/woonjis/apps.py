from django.apps import AppConfig


class WoonjisConfig(AppConfig):
    name = 'woonjis'

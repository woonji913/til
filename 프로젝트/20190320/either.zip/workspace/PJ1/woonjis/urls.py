from django.urls import path
from . import views

app_name = 'woonjis'

urlpatterns = [
    path('<int:question_pk>/answers/', views.answers_create, name='answers_create'),
    path('new/', views.new, name='new'),
    path('<int:question_pk>/', views.detail, name='detail'),
    path('', views.index, name='index'),
]